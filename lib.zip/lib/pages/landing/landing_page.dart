import 'package:nafahat/pages/widgets/shared_navigation_shell.dart';
// lib/pages/landing/landing_page.dart
import 'package:flutter/material.dart';
import 'package:nafahat/theme/app_theme_tokens.dart';
import 'package:nafahat/pages/widgets/mobile_bottom_nav_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nafahat/models/bull_model.dart';

import 'package:provider/provider.dart';

// Models
import 'package:nafahat/models/card_config_model.dart';
import 'package:nafahat/models/training_model.dart';
import 'package:nafahat/models/SectionOrderModel.dart';

// Services
import 'package:nafahat/services/training_service.dart';
import 'package:nafahat/services/bull_service.dart';
import 'package:nafahat/services/card_config_manager.dart';
import 'package:nafahat/services/SectionOrderService.dart';
import 'package:nafahat/services/landing_appearance_manager.dart';

// Providers
import 'package:nafahat/providers/language_provider.dart';

// Widgets
import 'package:nafahat/pages/widgets/inscription_section.dart';
import 'package:nafahat/pages/widgets/video_fav_section.dart';
import 'package:nafahat/pages/widgets/hero_section.dart';
import 'package:nafahat/pages/widgets/navbar.dart';
import 'package:nafahat/pages/widgets/training_card_section.dart';
import 'package:nafahat/pages/widgets/formateur_section.dart';

import 'package:nafahat/pages/widgets/all_video_page.dart';
import 'package:nafahat/pages/widgets/bull_lien_section.dart';
import 'package:nafahat/pages/widgets/about.dart';
import 'package:nafahat/pages/formateur/formateur_detail_page.dart';
import 'package:nafahat/pages/formation/video_detail_page.dart';


// Admin pages
import 'package:nafahat/pages/adminisration/add_training_card.dart';

// --- PALETTE DE COULEURS ---
class AppColors {
  static Color get primary => AppThemeTokens.accent;
  static Color get primaryDark => AppThemeTokens.title;
  static Color get primaryLight => AppThemeTokens.accentSoft;
  static Color get surface => AppThemeTokens.background;
  static Color get textDark => AppThemeTokens.text;
  static Color get textMuted => AppThemeTokens.muted;
}

// ============================================================
// LANDING PAGE PRINCIPALE
// ============================================================
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _trainingSectionKey = GlobalKey<_TrainingCyclesSectionState>();
  final ScrollController _pageScrollController = ScrollController();
  final Map<String, GlobalKey> _sectionKeys = {};
  final LandingAppearanceManager _appearanceManager = LandingAppearanceManager();

  void _onAppearanceChanged() {
    if (mounted) setState(() {});
  }

  void _onSectionsChanged() {
    _loadSections();
  }

  void _onBullsChanged() {
    if (mounted) setState(() {});
  }
  @override
  void dispose() {
    _appearanceManager.removeListener(_onAppearanceChanged);
    SectionOrderService.revision.removeListener(_onSectionsChanged);
    BullService.revision.removeListener(_onBullsChanged);
    _pageScrollController.dispose();
    super.dispose();
  }

  // États pour les sections dynamiques
  List<SectionOrderModel> _sections = SectionOrderService.getDefaultSections()
      .where((s) => s.isActive)
      .toList();
  bool _sectionsLoaded = true;

  @override
  void initState() {
    super.initState();
    _appearanceManager.addListener(_onAppearanceChanged);
    SectionOrderService.revision.addListener(_onSectionsChanged);
    BullService.revision.addListener(_onBullsChanged);
    _appearanceManager.load();
    _loadSections();
  }

  // ============================================================
  // CHARGEMENT DES SECTIONS
  // ============================================================
  Future<void> _loadSections() async {
    try {
      final sections = await SectionOrderService.loadSections();
      if (!mounted) return;

      final activeSections = sections.where((s) => s.isActive).toList()
        ..sort((a, b) => a.order.compareTo(b.order));

      // Une configuration vide/mal formée ne doit jamais rendre la landing vide.
      final safeSections = activeSections.isNotEmpty
          ? activeSections
          : SectionOrderService.getDefaultSections()
              .where((s) => s.isActive)
              .toList();

      setState(() {
        _sections = safeSections;
        final activeIds = safeSections.map((s) => s.id).toSet();
        _sectionKeys.removeWhere((id, _) => !activeIds.contains(id));
        _sectionsLoaded = true;
      });
    } catch (e) {
      debugPrint('LandingPage._loadSections: $e');
      if (mounted) {
        setState(() {
          _sections = SectionOrderService.getDefaultSections()
              .where((s) => s.isActive)
              .toList();
          _sectionsLoaded = true;
        });
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final args = ModalRoute.of(context)?.settings.arguments;
      if (args is Map && args['section'] is String) {
        _scrollToSection(args['section'] as String);
      }
    });
  }

  // ============================================================
  // GESTIONNAIRE DE CLIC SUR BULL - NAVIGATION INTELLIGENTE
  // ============================================================
  void _handleBullTap(BuildContext context, BullModel bull) {
    print('🔗 [BULL] Clic sur: ${bull.title}');
    print('   📍 Lien: ${bull.link}');
    
    final link = bull.link;
    
    // ✅ Si c'est un lien vers une catégorie
    if (link.startsWith('/categorie/')) {
      final categorieId = link.replaceAll('/categorie/', '');
      print('   🏷️ Navigation vers catégorie: $categorieId');
      
      Navigator.pushNamed(
        context,
        '/formations',
        arguments: {'categorieId': categorieId},
      );
      return;
    }
    
    // ✅ Si c'est un lien vers un formateur : ouvrir sa fiche d'information.
    if (link.startsWith('/formateur/')) {
      final formateurId = link.replaceAll('/formateur/', '').trim();
      print('   👤 Navigation vers la fiche formateur: $formateurId');

      if (formateurId.isNotEmpty) {
        Navigator.push(
          context,
          NafahatPageRoute(
            builder: (context) =>
                FormateurDetailPage(formateurId: formateurId),
          ),
        );
      }
      return;
    }
    
    // ✅ Si c'est un lien vers une formation
    if (link.startsWith('/formation/')) {
      final formationId = link.replaceAll('/formation/', '');
      print('   📚 Navigation vers formation: $formationId');
      
      Navigator.pushNamed(
        context,
        '/formation/$formationId',
      );
      return;
    }
    
    // ✅ Si c'est un lien vers une vidéo : ouvrir directement sa fiche.
    if (link.startsWith('/video/')) {
      final videoId = link.replaceAll('/video/', '').trim();
      print('   🎬 Navigation vers vidéo: $videoId');

      if (videoId.isNotEmpty) {
        Navigator.push(
          context,
          NafahatPageRoute(
            builder: (context) => VideoDetailPage(videoId: videoId),
          ),
        );
      }
      return;
    }
    
    // ✅ Si c'est un lien vers une section (scroll)
    if (link.startsWith('/section/')) {
      final sectionKey = link.replaceAll('/section/', '');
      print('   📑 Navigation vers section: $sectionKey');
      
      _scrollToSection(sectionKey);
      return;
    }
    
    // ✅ Pages gérées sans modifier la table des routes de l'application.
    if (link == '/' || link == '/landing') {
      _pageScrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOutCubic,
      );
      return;
    }

    if (link == '/about' || link == '/contact') {
      Navigator.push(
        context,
        NafahatPageRoute(builder: (context) => const AboutPage()),
      );
      return;
    }

    // ✅ Navigation standard pour les routes déjà existantes.
    print('   🔗 Navigation normale vers: $link');
    Navigator.pushNamed(context, link);
  }

  // ============================================================
  // SCROLL VERS UNE SECTION
  // ============================================================
  void _scrollToSection(String sectionKey) {
    for (final section in _sections) {
      if (section.sectionKey != sectionKey) continue;
      final target = _sectionKeys[section.id]?.currentContext;
      if (target != null) {
        // La marge réservée au Navbar fixe évite de cacher le titre ciblé.
        Scrollable.ensureVisible(target,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut, alignment: 0.18);
        return;
      }
    }
    final isArabic = context.read<LanguageProvider>().isArabic;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
      isArabic ? 'هذا القسم غير متاح حالياً.' : 'Cette section n’est pas disponible actuellement.',
    )));
  }

  // ============================================================
  // SECTION BULLS LIENS
  // ============================================================
  Widget _buildBullsSection(bool isArabic, bool isMobile) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: isMobile ? 8 : 50,
        vertical: 8,
      ),
      child: FutureBuilder<List<BullModel>>(
        future: BullService.getBulls(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return SizedBox(
              height: 50,
              child: Center(
                child: SizedBox(
                  height: 24,
                  width: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.primary,
                  ),
                ),
              ),
            );
          }

          if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
            return _buildDefaultBulls(isArabic);
          }

          final bulls = snapshot.data!;
          final activeBulls = bulls.where((b) => b.isActive).toList();

          if (activeBulls.isEmpty) {
            return _buildDefaultBulls(isArabic);
          }

          return BullsList(
            bulls: activeBulls,
            onBullTap: (bull) {
              _handleBullTap(context, bull);
            },
          );
        },
      ),
    );
  }

  Widget _buildDefaultBulls(bool isArabic) {
    final bulls = BullService.getDefaultBulls();
    return BullsList(
      bulls: bulls,
      onBullTap: (bull) {
        _handleBullTap(context, bull);
      },
    );
  }

  // ============================================================
  // RENDU DES SECTIONS DYNAMIQUES
  // ============================================================
  Widget _buildSection(SectionOrderModel section, bool isMobile, bool isArabic) {
    switch (section.sectionKey) {
      case PredefinedSections.hero:
        return HeroSection(isArabic: isArabic);

      case PredefinedSections.bulls:
        return _buildBullsSection(isArabic, isMobile);

      case PredefinedSections.trainings:
        return _TrainingCyclesSection(
          key: _trainingSectionKey,
          isArabic: isArabic,
        );

      case PredefinedSections.inscription:
        return Padding(
          padding: EdgeInsets.symmetric(
            horizontal: isMobile ? 0 : 20,
            vertical: 10,
          ),
          child: InscriptionSection(
            isArabic: isArabic,
            fullWidth: true,
            showIcon: true,
            showSubtitle: true,
          ),
        );

      case PredefinedSections.videos:
        return VideoFavSection(isArabic: isArabic);

      case PredefinedSections.formateurs:
        return _FormateurSection(isArabic: isArabic);

      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildStyledSection(
    SectionOrderModel section,
    bool isMobile,
    bool isArabic,
  ) {
    final cfg = _appearanceManager.config;
    final content = _buildSection(section, isMobile, isArabic);
    final shouldDecorate =
        cfg.showSectionCards && section.sectionKey != PredefinedSections.hero;

    final title = isArabic ? section.titleAr : section.title;
    final header = cfg.showSectionTitles &&
            section.sectionKey != PredefinedSections.hero &&
            title.trim().isNotEmpty
        ? Padding(
            padding: EdgeInsets.fromLTRB(
              isMobile ? 16 : cfg.horizontalPadding,
              10,
              isMobile ? 16 : cfg.horizontalPadding,
              8,
            ),
            child: Align(
              alignment:
                  isArabic ? Alignment.centerRight : Alignment.centerLeft,
              child: Text(
                title,
                style: cfg.titleStyle(
                  size: isMobile
                      ? (cfg.titleFontSize - 4).clamp(18, 36).toDouble()
                      : cfg.titleFontSize,
                ),
              ),
            ),
          )
        : const SizedBox.shrink();

    return Padding(
      padding: EdgeInsets.only(
        left: shouldDecorate && !isMobile ? cfg.horizontalPadding : 0,
        right: shouldDecorate && !isMobile ? cfg.horizontalPadding : 0,
        bottom: cfg.compactMode
            ? cfg.sectionSpacing * 0.5
            : cfg.sectionSpacing,
      ),
      child: Container(
        decoration: shouldDecorate
            ? BoxDecoration(
                color: cfg.sectionBackgroundColor,
                borderRadius: BorderRadius.circular(cfg.sectionRadius),
                boxShadow: cfg.enableSectionShadow
                    ? [
                        BoxShadow(
                          color: Colors.black.withOpacity(
                            cfg.themeMode == 'dark' ? 0.24 : 0.08,
                          ),
                          blurRadius: 22,
                          offset: const Offset(0, 8),
                        ),
                      ]
                    : null,
              )
            : null,
        clipBehavior:
            shouldDecorate ? Clip.antiAlias : Clip.none,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            header,
            content,
          ],
        ),
      ),
    );
  }

  // ============================================================
  // BUILD PRINCIPAL
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.isArabic;
    final bool isMobile = MediaQuery.of(context).size.width < 850;
    final landingAppearance = _appearanceManager.config;

    if (!_sectionsLoaded) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );
    }

    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: landingAppearance.pageBackgroundColor,
        drawer: isMobile
            ? Navbar(
                isMobile: true,
                scaffoldKey: _scaffoldKey,
              ).buildDrawer(context)
            : null,
        body: SafeArea(
          top: false,
          child: Column(
            children: [
              // Contenu principal
              Expanded(
                child: Stack(
                  children: [
                    SingleChildScrollView(
                      controller: _pageScrollController,
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          SizedBox(height: landingAppearance.compactMode ? 6 : 12),

                          // ✅ SECTIONS DYNAMIQUES (selon l'ordre défini dans l'admin)
                          ..._sections.map((section) {
                            return KeyedSubtree(
                              key: _sectionKeys.putIfAbsent(
                                section.id,
                                () => GlobalKey(),
                              ),
                              child: _buildStyledSection(
                                section,
                                isMobile,
                                isArabic,
                              ),
                            );
                          }).toList(),

                          SizedBox(height: landingAppearance.compactMode ? 18 : 40),
                        ],
                      ),
                    ),
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      child: Navbar(isMobile: isMobile, scaffoldKey: _scaffoldKey),
                    ),

                  ],
                ),
              ),
              // ============================================================
              // ✅ MOBILE BOTTOM NAVIGATION
              // ============================================================
              const MobileBottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  void refreshTrainings() {
    _trainingSectionKey.currentState?.refreshTrainings();
  }
}

// ============================================================
// SECTION FORMATIONS (UNE SEULE LIGNE)
// ============================================================
class _TrainingCyclesSection extends StatefulWidget {
  final bool isArabic;

  const _TrainingCyclesSection({super.key, required this.isArabic});

  @override
  State<_TrainingCyclesSection> createState() => _TrainingCyclesSectionState();
}

class _TrainingCyclesSectionState extends State<_TrainingCyclesSection> {
  List<TrainingModel> _allTrainings = [];
  List<TrainingModel> _filteredTrainings = [];
  List<TrainingModel> _displayedTrainings = [];
  bool _isLoading = true;

  String _selectedCategorie = 'Toutes';
  String _selectedTypeFormation = 'Tous';
  String _selectedFormateur = 'Tous';
  List<String> _categories = ['Toutes'];
  List<String> _typesFormation = ['Tous'];
  List<String> _formateurs = ['Tous'];

  @override
  void initState() {
    super.initState();
    _loadTrainings();
  }

  List<TrainingModel> _getTrainingsToDisplay() {
    final isMobile = MediaQuery.of(context).size.width < 600;
    
    // ✅ Récupérer la config depuis le provider
    final cardConfigManager = Provider.of<CardConfigManager>(context, listen: false);
    final config = cardConfigManager.config;

    if (_allTrainings.isEmpty) return [];

    if (isMobile) {
      final displayCount = config.mobileDisplayCount;
      final selectedIds = config.mobileSelectedTrainings;

      if (selectedIds.isNotEmpty) {
        final selected = <TrainingModel>[];
        for (final id in selectedIds) {
          try {
            final training = _allTrainings.firstWhere((t) => t.id == id);
            selected.add(training);
          } catch (e) {
            // Ignorer si l'ID n'existe pas
          }
        }
        if (selected.isNotEmpty) {
          return selected.take(displayCount).toList();
        }
      }
      return _allTrainings.take(displayCount).toList();
    }

    return _allTrainings.take(6).toList();
  }

  Future<void> _loadTrainings() async {
    try {
      final trainings = await TrainingService.getTrainings();
      setState(() {
        _allTrainings = trainings.reversed.toList();
        _extractFilters();
        _applyFilters();
        _updateDisplayedTrainings();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _allTrainings = [];
        _filteredTrainings = [];
        _displayedTrainings = [];
        _isLoading = false;
      });
    }
  }

  void _updateDisplayedTrainings() {
    _displayedTrainings = _getTrainingsToDisplay();
  }

  void _extractFilters() {
    final cats = <String>{'Toutes'};
    final types = <String>{'Tous'};
    final formateurs = <String>{'Tous'};

    for (var t in _allTrainings) {
      if (t.categorieFr.isNotEmpty) cats.add(t.categorieFr);
      if (t.categorieAr.isNotEmpty) cats.add(t.categorieAr);
      if (t.typeFormation.isNotEmpty) types.add(t.typeFormation);
      if (t.trainer.isNotEmpty) formateurs.add(t.trainer);
    }

    setState(() {
      _categories = cats.toList();
      _typesFormation = types.toList();
      _formateurs = formateurs.toList();

      if (!_categories.contains(_selectedCategorie)) {
        _selectedCategorie = 'Toutes';
      }
      if (!_typesFormation.contains(_selectedTypeFormation)) {
        _selectedTypeFormation = 'Tous';
      }
      if (!_formateurs.contains(_selectedFormateur)) {
        _selectedFormateur = 'Tous';
      }
    });
  }

  void _applyFilters() {
    _filteredTrainings = _allTrainings.where((t) {
      bool matchCategorie = _selectedCategorie == 'Toutes' ||
          t.categorieFr == _selectedCategorie ||
          t.categorieAr == _selectedCategorie;
      bool matchType = _selectedTypeFormation == 'Tous' ||
          t.typeFormation == _selectedTypeFormation;
      bool matchFormateur = _selectedFormateur == 'Tous' ||
          t.trainer == _selectedFormateur;
      return matchCategorie && matchType && matchFormateur;
    }).toList();

    _updateDisplayedTrainings();
  }

  Future<void> refreshTrainings() async {
    setState(() => _isLoading = true);
    await _loadTrainings();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final landingAppearance = LandingAppearanceManager().config;
    final isMobile = screenWidth < 600;
    final isTablet = screenWidth >= 600 && screenWidth < 900;
    final paddingHorizontal = isMobile ? 0.0 : (isTablet ? 32.0 : 50.0);

    // ✅ Mettre à jour l'affichage à chaque build (pour réagir aux changements de config)
    _updateDisplayedTrainings();

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: paddingHorizontal,
        vertical: 20,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 16.0 : 0.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.isArabic
                      ? "برامجنا التدريبية"
                      : "Nos Cycles de Formation",
                  style: landingAppearance.titleStyle(
                    size: isMobile
                        ? (landingAppearance.titleFontSize - 4)
                            .clamp(18, 34)
                            .toDouble()
                        : landingAppearance.titleFontSize,
                  ),
                ),
                Row(
                  children: [
                    if (isMobile && _allTrainings.length > 3)
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            NafahatPageRoute(
                              builder: (context) => const AllTrainingsPage(),
                            ),
                          );
                        },
                        style: TextButton.styleFrom(
                          foregroundColor: AppColors.primary,
                        ),
                        child: Text(
                          widget.isArabic
                              ? 'اكتشف المزيد >>>'
                              : 'Découvrir plus >>>',
                          style: GoogleFonts.cairo(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    IconButton(
                      icon: Icon(Icons.refresh, color: AppColors.primary),
                      onPressed: refreshTrainings,
                      tooltip: widget.isArabic ? 'تحديث' : 'Rafraîchir',
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ✅ FILTRES (uniquement desktop)
          if (!isMobile && _allTrainings.isNotEmpty)
            _buildFilters(isMobile),

          if (_isLoading)
            const Center(child: CircularProgressIndicator())
          else if (_allTrainings.isEmpty)
            _buildEmptyState()
          else if (_displayedTrainings.isEmpty && isMobile)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    Icon(
                      Icons.info_outline,
                      size: 48,
                      color: AppColors.textMuted.withOpacity(0.3),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      widget.isArabic
                          ? 'Aucune formation disponible pour l\'affichage mobile'
                          : 'Aucune formation disponible pour l\'affichage mobile',
                      style: GoogleFonts.cairo(
                        color: AppColors.textMuted,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          NafahatPageRoute(
                            builder: (context) => const AllTrainingsPage(),
                          ),
                        );
                      },
                      child: Text(
                        widget.isArabic
                            ? 'Voir toutes les formations'
                            : 'Voir toutes les formations',
                        style: GoogleFonts.cairo(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          else if (_filteredTrainings.isEmpty && !isMobile)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Text(
                  widget.isArabic
                      ? 'لا توجد تكوينات تطابق الفلتر'
                      : 'Aucune formation ne correspond aux filtres',
                  style: GoogleFonts.cairo(
                    color: AppColors.textMuted,
                    fontSize: 16,
                  ),
                ),
              ),
            )
          else
            _buildTrainingRow(isMobile, isTablet),
        ],
      ),
    );
  }

  Widget _buildFilters(bool isMobile) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Wrap(
        spacing: 12,
        runSpacing: 8,
        children: [
          _buildElegantFilter(
            value: _selectedCategorie,
            items: _categories,
            label: widget.isArabic ? 'التصنيف' : 'Catégorie',
            icon: Icons.category_outlined,
            onChanged: (value) {
              setState(() {
                _selectedCategorie = value!;
                _applyFilters();
              });
            },
            isArabic: widget.isArabic,
          ),
          _buildElegantFilter(
            value: _selectedTypeFormation,
            items: _typesFormation,
            label: widget.isArabic ? 'النوع' : 'Type',
            icon: Icons.school_outlined,
            onChanged: (value) {
              setState(() {
                _selectedTypeFormation = value!;
                _applyFilters();
              });
            },
            isArabic: widget.isArabic,
          ),
          _buildElegantFilter(
            value: _selectedFormateur,
            items: _formateurs,
            label: widget.isArabic ? 'المكون' : 'Formateur',
            icon: Icons.person_outline,
            onChanged: (value) {
              setState(() {
                _selectedFormateur = value!;
                _applyFilters();
              });
            },
            isArabic: widget.isArabic,
          ),
        ],
      ),
    );
  }

  Widget _buildTrainingRow(bool isMobile, bool isTablet) {
    final trainings = isMobile ? _displayedTrainings : _filteredTrainings;

    double cardWidth;
    double cardHeight;

    if (isMobile) {
      // ✅ Ratio Reel Facebook/Instagram = 9:16 (largeur:hauteur)
      cardWidth = 150.0;
      cardHeight = 150.0 / (9 / 16); // ≈ 266.7
    } else if (isTablet) {
      cardWidth = 280.0;
      cardHeight = 300.0;
    } else {
      cardWidth = 300.0;
      cardHeight = 320.0;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: isMobile ? 16.0 : 0.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                widget.isArabic
                    ? '${trainings.length} تكوين'
                    : '${trainings.length} formation${trainings.length > 1 ? 's' : ''}',
                style: GoogleFonts.cairo(
                  color: AppColors.textMuted,
                  fontSize: 14,
                ),
              ),
              if (!isMobile && _allTrainings.length > 6)
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      NafahatPageRoute(
                        builder: (context) => const AllTrainingsPage(),
                      ),
                    );
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                  child: Row(
                    children: [
                      Text(
                        widget.isArabic
                            ? 'اكتشف المزيد من الدورات'
                            : 'Découvrir plus de formations',
                        style: GoogleFonts.cairo(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.primary,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Icon(
                        Icons.arrow_forward_rounded,
                        color: AppColors.primary,
                        size: 18,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: cardHeight,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: trainings.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 12, left: 4),
                child: SizedBox(
                  width: cardWidth,
                  height: cardHeight,
                  child: TrainingCard(
                    training: trainings[index],
                    isArabic: widget.isArabic,
                    onRefresh: refreshTrainings,
                    isMobile: isMobile,
                  ),
                ),
              );
            },
          ),
        ),
        if (isMobile && _allTrainings.length > 3)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  NafahatPageRoute(
                    builder: (context) => const AllTrainingsPage(),
                  ),
                );
              },
              style: TextButton.styleFrom(foregroundColor: AppColors.primary),
              child: Text(
                widget.isArabic
                    ? 'اكتشف المزيد من الدورات >>>'
                    : 'Découvrir plus de formations >>>',
                style: GoogleFonts.cairo(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.primary,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildElegantFilter({
    required String value,
    required List<String> items,
    required String label,
    required IconData icon,
    required ValueChanged<String?> onChanged,
    required bool isArabic,
  }) {
    final uniqueItems = items.toSet().toList();
    final selectedValue = uniqueItems.contains(value) ? value : uniqueItems.first;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.primary.withOpacity(0.15)),
        borderRadius: BorderRadius.circular(30),
        color: Colors.white,
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        underline: const SizedBox(),
        hint: Row(
          children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 4),
            Text(
              label,
              style: GoogleFonts.cairo(
                fontSize: 13,
                color: AppColors.textMuted,
              ),
            ),
          ],
        ),
        items: uniqueItems.map((item) {
          String displayText = item;
          if (item == 'Tous' || item == 'Toutes') {
            displayText = isArabic ? 'الكل' : 'Tous';
          } else {
            if (isArabic) {
              for (var t in _allTrainings) {
                if (t.categorieFr == item && t.categorieAr.isNotEmpty) {
                  displayText = t.categorieAr;
                  break;
                }
              }
            }
          }
          return DropdownMenuItem<String>(
            value: item,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                displayText,
                style: GoogleFonts.cairo(fontSize: 13),
              ),
            ),
          );
        }).toList(),
        onChanged: onChanged,
        icon: Icon(Icons.keyboard_arrow_down, color: AppColors.primary),
        dropdownColor: Colors.white,
        style: GoogleFonts.cairo(color: AppColors.textDark),
        elevation: 2,
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        children: [
          Icon(
            Icons.school_outlined,
            size: 80,
            color: AppColors.primary.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Text(
            widget.isArabic
                ? 'لا توجد تكوينات حالياً'
                : 'Aucune formation disponible',
            style: GoogleFonts.cairo(color: AppColors.textMuted, fontSize: 16),
          ),
          const SizedBox(height: 8),
          Text(
            widget.isArabic
                ? 'قم بإضافة تكوين جديد من لوحة التحكم'
                : 'Ajoutez une formation depuis le panneau d\'administration',
            style: GoogleFonts.cairo(
              color: AppColors.textMuted.withOpacity(0.7),
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.push(
                context,
                NafahatPageRoute(
                  builder: (context) => const AddTrainingCardPage(),
                ),
              ).then((_) {
                refreshTrainings();
              });
            },
            icon: const Icon(Icons.add),
            label: Text(
              widget.isArabic ? 'إضافة تكوين' : 'Ajouter une formation',
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SECTION FORMATEURS (UNE SEULE LIGNE)
// ============================================================
class _FormateurSection extends StatefulWidget {
  final bool isArabic;

  const _FormateurSection({required this.isArabic});

  @override
  State<_FormateurSection> createState() => _FormateurSectionState();
}

class _FormateurSectionState extends State<_FormateurSection> {
  List<Map<String, dynamic>> _formateurs = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFormateurs();
  }

  Future<void> _loadFormateurs() async {
    try {
      final formateurs = await TrainingService.getFormateurs();
      setState(() {
        _formateurs = formateurs;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _formateurs = [];
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = widget.isArabic;
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: isMobile ? 16 : 50,
        vertical: 20,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'مكونونا' : 'Nos Formateurs',
            style: LandingAppearanceManager().config.titleStyle(
              size: isMobile
                  ? (LandingAppearanceManager().config.titleFontSize - 4)
                      .clamp(18, 34)
                      .toDouble()
                  : LandingAppearanceManager().config.titleFontSize,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            isArabic
                ? 'خبراء في مجالاتهم لمرافقتك في رحلتك التعليمية'
                : 'Des experts dans leurs domaines pour vous accompagner',
            style: GoogleFonts.cairo(
              fontSize: isMobile ? 14 : 16,
              color: LandingAppearanceManager().config.mutedTextColor,
            ),
          ),
          const SizedBox(height: 16),

          if (_isLoading)
            const Center(child: CircularProgressIndicator())
          else if (_formateurs.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    Icon(
                      Icons.person_outline,
                      size: 48,
                      color: AppColors.textMuted.withOpacity(0.3),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      isArabic
                          ? 'لا يوجد مكونين حالياً'
                          : 'Aucun formateur disponible',
                      style: GoogleFonts.cairo(
                        color: AppColors.textMuted,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            _buildFormateurRow(isMobile),
        ],
      ),
    );
  }

  Widget _buildFormateurRow(bool isMobile) {
    final displayedFormateurs =
        _formateurs.length > 8 ? _formateurs.sublist(0, 8) : _formateurs;

    double cardWidth = isMobile ? 180.0 : 220.0;
    double cardHeight = isMobile ? 195.0 : 225.0;

    return SizedBox(
      height: cardHeight + 20,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: displayedFormateurs.length,
        itemBuilder: (context, index) {
          final formateur = displayedFormateurs[index];
          return Padding(
            padding: const EdgeInsets.only(right: 12, left: 4),
            child: SizedBox(
              width: cardWidth,
              height: cardHeight,
              child: FormateurCard(
                formateur: formateur,
                isArabic: widget.isArabic,
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// PAGE "TOUTES LES FORMATIONS"
// ============================================================
class AllTrainingsPage extends StatefulWidget {
  const AllTrainingsPage({super.key});

  @override
  State<AllTrainingsPage> createState() => _AllTrainingsPageState();
}

class _AllTrainingsPageState extends State<AllTrainingsPage> {
  List<TrainingModel> _trainings = [];
  bool _isLoading = true;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _loadAllTrainings();
  }

  Future<void> _loadAllTrainings() async {
    try {
      final trainings = await TrainingService.getTrainings();
      setState(() {
        _trainings = trainings.reversed.toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _trainings = [];
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = Provider.of<LanguageProvider>(context).isArabic;
    final isMobile = MediaQuery.of(context).size.width < 600;
    final navbar = Navbar(isMobile: isMobile, scaffoldKey: _scaffoldKey);

    return Column(
      children: [
        navbar,
        Expanded(
          child: Scaffold(
            key: _scaffoldKey,
            drawer: isMobile ? navbar.buildDrawer(context) : null,
            appBar: AppBar(
              title: Text(
                isArabic ? 'جميع التكوينات' : 'Toutes les formations',
                style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
              ),
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 0,
              actions: [
                IconButton(
                  icon: const Icon(Icons.refresh),
                  onPressed: _loadAllTrainings,
                  tooltip: isArabic ? 'تحديث' : 'Rafraîchir',
                ),
              ],
            ),
            body: Column(
              children: [
                Expanded(
                  child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : _trainings.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.school_outlined,
                                    size: 80,
                                    color: AppColors.primary.withOpacity(0.3),
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    isArabic
                                        ? 'لا توجد تكوينات حالياً'
                                        : 'Aucune formation disponible',
                                    style: GoogleFonts.cairo(
                                      color: AppColors.textMuted,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Padding(
                              padding: EdgeInsets.all(isMobile ? 12 : 24),
                              child: GridView.builder(
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: isMobile ? 2 : 3,
                                  childAspectRatio: isMobile ? 9 / 16 : 0.85,
                                  crossAxisSpacing: 16,
                                  mainAxisSpacing: 16,
                                ),
                                itemCount: _trainings.length,
                                itemBuilder: (context, index) {
                                  return TrainingCard(
                                    training: _trainings[index],
                                    isArabic: isArabic,
                                    onRefresh: _loadAllTrainings,
                                    isMobile: isMobile,
                                  );
                                },
                              ),
                            ),
                ),
                const MobileBottomNav(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

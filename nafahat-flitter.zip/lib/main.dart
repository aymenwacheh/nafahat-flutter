import 'package:nafahat/pages/widgets/shared_navigation_shell.dart';
import 'package:nafahat/pages/widgets/mobile_bottom_nav_bar.dart';
// lib/main.dart
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:nafahat/pages/formation/formations_page.dart';
import 'package:nafahat/pages/formateur/formateurs_page.dart';
import 'package:nafahat/pages/widgets/chatbot/chatbot_widget.dart';
import 'package:nafahat/pages/users/inscription_adherent.dart';
import 'package:provider/provider.dart';
import 'package:nafahat/pages/landing/splash_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nafahat/pages/users/auth_page.dart';
import 'package:nafahat/providers/language_provider.dart';
import 'package:nafahat/providers/chatbot_provider.dart';
import 'package:nafahat/providers/user_provider.dart';
import 'package:nafahat/providers/about_provider.dart';
import 'package:nafahat/providers/hero_provider.dart';
import 'pages/widgets/chatbot/chatbot_widget.dart';
import 'package:nafahat/config/api_config.dart';
import 'pages/landing/landing_page.dart';
import 'package:nafahat/pages/users/profile_dashboard_page.dart';
import 'package:nafahat/pages/adminisration/administration_page.dart';
import 'package:nafahat/pages/cart/cart_page.dart';
import 'services/navigation_service.dart';
import 'services/cart_service.dart';
import 'services/card_config_manager.dart';
import 'package:nafahat/pages/widgets/all_video_page.dart';
import 'pages/formation/formation_detail_page.dart';
import 'package:nafahat/pages/users/reset_password_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  CartService.init();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isInitialized = false;
  CardConfigManager? _cardConfigManager;
  HeroProvider? _heroProvider;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    print('🚀 Début initialisation...');
    
    // Initialiser CardConfigManager
    _cardConfigManager = CardConfigManager();
    await _cardConfigManager!.init();
    print('✅ CardConfigManager initialisé');
    
    // Initialiser HeroProvider
    _heroProvider = HeroProvider();
    await _heroProvider!.init();
    print('✅ HeroProvider initialisé avec ${_heroProvider!.slides.length} slides');
    
    setState(() {
      _isInitialized = true;
    });
    print('🚀 Initialisation terminée');
  }

  Widget _getInitialPage() {
    if (!kIsWeb) {
      return ChatbotGlobalWrapper(child: const SplashScreen());
    }

    final Uri uri = Uri.base;
    final String path = uri.path;

    if (path == '/' || path.isEmpty) {
      return const ComingSoonPage();
    } else if (path == '/project') {
      return ChatbotGlobalWrapper(child: const SplashScreen());
    } else if (path == '/reset-password') {
      return const ChatbotGlobalWrapper(
        hideOnRoute: false,
        child: ResetPasswordPage(),
      );
    } else {
      return const ComingSoonPage();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return MaterialApp(
        home: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircularProgressIndicator(color: Color(0xffd57653)),
                const SizedBox(height: 20),
                Text(
                  'Chargement...',
                  style: GoogleFonts.cairo(
                    color: Colors.grey[600],
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
        ChangeNotifierProvider(create: (_) => ChatbotProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => AboutProvider()),
        // ✅ Utiliser les instances déjà initialisées
        ChangeNotifierProvider<CardConfigManager>.value(
          value: _cardConfigManager!,
        ),
        ChangeNotifierProvider<HeroProvider>.value(
          value: _heroProvider!,
        ),
      ],
      child: Consumer<LanguageProvider>(
        builder: (context, languageProvider, child) {
          print('📍 Langue actuelle: ${languageProvider.languageCode}');
          
          // Vérifier les providers
          final cardConfigManager = Provider.of<CardConfigManager>(context);
          final heroProvider = Provider.of<HeroProvider>(context);
          
          print('📍 Config chargée: ${cardConfigManager.isInitialized}');
          print('📍 Hero chargé: ${heroProvider.isInitialized} - ${heroProvider.slides.length} slides');

          return MaterialApp(
            title: 'Nafahat Platform',
            debugShowCheckedModeBanner: false,
            locale: languageProvider.locale,
            navigatorKey: NavigationService.navigatorKey,
            theme: ThemeData(
              textTheme: GoogleFonts.cairoTextTheme(),
              appBarTheme: AppBarTheme(
                titleTextStyle: GoogleFonts.cairo(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
                toolbarTextStyle: GoogleFonts.cairo(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
              primarySwatch: Colors.indigo,
            ),
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: const [
              Locale('ar', 'AR'),
              Locale('fr', 'FR'),
              Locale('en', 'US'),
            ],
            localeResolutionCallback: (deviceLocale, supportedLocales) {
              return const Locale('ar');
            },
            navigatorObservers: [ChatbotRouteObserver()],
            builder: (context, child) {
              return NotificationListener<ScrollNotification>(
                onNotification: MobileBottomNavController.handleScroll,
                child: child ?? const SizedBox.shrink(),
              );
            },
            home: _getInitialPage(),
            routes: {
              '/landing': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: true,
                child: LandingPage(),
              ),
              '/splash': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: true,
                child: SplashScreen(),
              ),
              '/auth': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: false,
                child: AuthPage(),
              ),
              '/admin': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: false,
                child: AdministrationPage(),
              ),
              '/cart': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: false,
                child: CartPage(),
              ),
              '/formateurs': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: false,
                child: FormateursPage(),
              ),
              '/reset-password': (context) => const ChatbotGlobalWrapper(
                hideOnRoute: false,
                child: ResetPasswordPage(),
              ),
            },
            onGenerateRoute: (settings) {
              print('📍 [ROUTE] Navigation vers: ${settings.name}');
              
              if (settings.name == '/login') {
                final args = settings.arguments as Map<String, dynamic>?;
                final returnToPrevious = args?['returnToPrevious'] as bool? ?? false;
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: AuthPage(returnToPrevious: returnToPrevious),
                  ),
                );
              }

              if (settings.name == '/inscription') {
                final args = settings.arguments as Map<String, dynamic>?;
                final fromFormationDetail = args?['fromFormationDetail'] as bool? ?? false;
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: InscriptionAdherentPage(
                      fromFormationDetail: fromFormationDetail,
                    ),
                  ),
                );
              }

              if (settings.name == '/reset-password') {
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => const ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: ResetPasswordPage(),
                  ),
                );
              }

              if (settings.name == '/formations') {
                final args = settings.arguments as Map<String, String>?;
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: FormationsPage(
                      categorieId: args?['categorieId'],
                      formateurId: args?['formateurId'],
                    ),
                  ),
                );
              }

              if (settings.name != null && settings.name!.startsWith('/formation/')) {
                final formationId = settings.name!.replaceAll('/formation/', '');
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: FormationDetailPage(formationId: formationId),
                  ),
                );
              }

              if (settings.name != null && settings.name!.startsWith('/video/')) {
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: AllVideoPage(),
                  ),
                );
              }

              if (settings.name == '/cart') {
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => const ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: CartPage(),
                  ),
                );
              }

              if (settings.name == '/profile') {
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: ProfileDashboardPage(),
                  ),
                );
              }

              if (settings.name == '/videos') {
                return NafahatPageRoute(
                  settings: settings,
                  builder: (context) => ChatbotGlobalWrapper(
                    hideOnRoute: false,
                    child: AllVideoPage(),
                  ),
                );
              }

              return null;
            },
            onUnknownRoute: (settings) {
              print('⚠️ [ROUTE] Route inconnue: ${settings.name}');
              return NafahatPageRoute(
                builder: (context) => const ChatbotGlobalWrapper(
                  hideOnRoute: false,
                  child: AuthPage(),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// 👇 OBSERVATEUR DE ROUTE
class ChatbotRouteObserver extends NavigatorObserver {
  static const List<String> _hideRoutes = ['/splash', '/landing'];

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    _updateChatbotVisibility(route.settings.name);
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    _updateChatbotVisibility(previousRoute?.settings.name);
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    _updateChatbotVisibility(newRoute?.settings.name);
  }

  void _updateChatbotVisibility(String? routeName) {
    MobileBottomNavController.reset();
    final context = navigator?.context;
    if (context != null) {
      final chatbotProvider = Provider.of<ChatbotProvider>(context, listen: false);
      final shouldHide = _hideRoutes.contains(routeName);
      if (shouldHide) {
        chatbotProvider.hide();
      } else {
        chatbotProvider.show();
      }
    }
  }
}

// 📄 PAGE COMING SOON
class ComingSoonPage extends StatefulWidget {
  const ComingSoonPage({super.key});

  @override
  State<ComingSoonPage> createState() => _ComingSoonPageState();
}

class _ComingSoonPageState extends State<ComingSoonPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat(reverse: true);
    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.12).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const Color orangeColor = Color.fromARGB(255, 180, 5, 20);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/slide1.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.15),
                Colors.black.withOpacity(0.4),
              ],
            ),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.only(top: 220.0),
                  child: AnimatedBuilder(
                    animation: _scaleAnimation,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: _scaleAnimation.value,
                        child: AbsorbPointer(
                          absorbing: true,
                          child: ElevatedButton.icon(
                            onPressed: null,
                            icon: Icon(Icons.hourglass_empty, size: 28, color: orangeColor),
                            label: Text(
                              'Coming Soon',
                              style: GoogleFonts.cairo(
                                fontSize: 18,
                                color: orangeColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                                side: const BorderSide(color: orangeColor, width: 2),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ✅ WRAPPER avec ChatbotProvider
class ChatbotGlobalWrapper extends StatefulWidget {
  final Widget child;
  final bool hideOnRoute;
  const ChatbotGlobalWrapper({super.key, required this.child, this.hideOnRoute = false});

  @override
  State<ChatbotGlobalWrapper> createState() => _ChatbotGlobalWrapperState();
}

class _ChatbotGlobalWrapperState extends State<ChatbotGlobalWrapper> {
  @override
  void initState() {
    super.initState();
    if (widget.hideOnRoute) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final provider = Provider.of<ChatbotProvider>(context, listen: false);
        provider.hide();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isArabic = Provider.of<LanguageProvider>(context).isArabic;
    final chatbotProvider = Provider.of<ChatbotProvider>(context);
    bool showChatbot = chatbotProvider.isVisible;

    if (widget.child is SplashScreen || widget.child is LandingPage) {
      showChatbot = false;
    }

    final route = ModalRoute.of(context);
    final routeName = route?.settings.name ?? '';
    if (routeName == '/splash' || routeName == '/landing') {
      showChatbot = false;
    }

    if (widget.child is SplashScreen) return widget.child;

    return Stack(
      children: [
        widget.child,
        if (showChatbot)
          ChatbotWidget(
            apiBaseUrl: ApiConfig.apiUrl,
            langue: isArabic ? 'ar' : 'fr',
            primaryColor: const Color(0xffd57653),
          ),
      ],
    );
  }
}